from time import sleep
from tkinter import *



    
def bt_clear(): 
    ent.delete(0,END)
    ent1.delete(0,END)
    
def bt_clear1(): 
    global ent3,ent5
    ent3.delete(0,END)
    ent5.delete(0,END)
lst_3 = []
def pass_w1():
        inp2 = ent3.get()
        inp_3 = int(ent5.get())
        lst_abc = ['1','2','3','4','5','7','6','8','10','9','0','!','@','#','$','%','^','&','*','(',')','_','+','=','-','?','/','>','<',':', 'a','b','c','d','e','f',' ','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','N','W','X','Y','Z']
        count = 0
        while len(inp2) >= count:
            global root2
            for i in inp2:
                global index_text
                index_test = lst_abc.index(i)
                index_full = index_test - inp_3
                index_text1 = lst_abc[index_full]
                lst_3.append(index_text1)
                a = Label(root2,text = 'Success:{}'.format(lst_3))
            a.grid(row=6,columnspan=3)
            break
                
                
                
                
                
                

   



    
    
        
       

def analyze():
    def pass_w():
        global a  
        lst = [
            
        ]
    
        inp = ent.get()
        inp_2 = int(ent1.get())
        lst_abc = ['1','2','3','4','5','7','6','8','10','9','0','!','@','#','$','%','^','&','*','(',')','_','+','=','-','?','/','>','<',':', 'a','b','c','d','e','f',' ','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','N','W','X','Y','Z']
        count = 0
        while len(inp) >= count:
            global a
            for i in inp:
                global index_text
                index_test = lst_abc.index(i)
                index_full = index_test + inp_2
                index_text = lst_abc[index_full]
                lst.append(index_text)
                a = Label(root1,text = 'Success:{}'.format(lst))
                a.grid(row=6,columnspan=3)
                
            
            break
    global label1,root1,lbl10
    global ent1,ent,root2
    
    get1 = Checkbutton1.get()
    get2 = Checkbutton2.get()
    if get1 == 1 and get2 == 1:
        label2 = Label(root,text = 'You can not choose two options')
        label2.pack()
    elif get1 == 0 and get2 == 0:
        label1 = Label(root,text = 'You have to chose')
        label1.pack()
    elif get1 == 1:
        root.destroy()
        sleep(1)
        root1 = Tk()
        root1.title('Encoding')
        root1.resizable(0,0)
        root1.tk.call('wm', 'iconphoto', root._w,PhotoImage(file='icon.ico'))
        
        lbl1 = Label(root1,text ='Enter password',justify='left')
        lbl1.grid(row=2,column=1)
        ent = Entry(root1)
        ent.grid(row=2,column= 3)
        lbl2 = Label(root1,text ='Enter Key')
        lbl2.grid(row=4,column=1)
        ent1 = Entry(root1)
        ent1.grid(row=4,column=3)
        submit2 = Button(root1,text='Submit',command=pass_w,fg='Black',bd=8)
        submit2.grid(row=5,column=3)
        clear = Button(root1,text=' Clear ',fg='black',command = lambda : bt_clear())
        clear.grid(row=5,column=4)
        
        root1.mainloop()
    elif get2 == 1:
        global ent3,ent5
        root.destroy()
        sleep(1)
        root2 = Tk()
        root2.title('Restore')
        root2.resizable(0,0)
        root2.tk.call('wm', 'iconphoto', root._w,PhotoImage(file='icon.ico'))
        lbl_1 = Label(root2,text ='Restore TXT',justify='left')
        lbl_1.grid(row=2,column=1)
        ent3 = Entry(root2)
        ent3.grid(row=2,column= 3)
        lbl4 = Label(root2,text ='Enter Key')
        lbl4.grid(row=4,column=1)
        ent5 = Entry(root2)
        ent5.grid(row=4,column=3)
        submit3 = Button(root2,text='Submit',command=pass_w1,fg='Black',bd=8)
        submit3.grid(row=5,column=3)
        clear1 = Button(root2,text=' Clear ',fg='black',command = lambda : bt_clear1())
        clear1.grid(row=5,column=4)
        root2.mainloop()
    
        
        
    
        
    
        

root = Tk()
root.title('Encoding and Restore')
root.geometry("300x200")
root.resizable(0,0)
root.tk.call('wm', 'iconphoto', root._w,PhotoImage(file='icon.ico'))

w = Label(root, text ='Program Encoding And Restore', font = "50",bg='red')
w.pack()

Checkbutton1 = IntVar()
Checkbutton2 = IntVar()


Button1 = Checkbutton(root, text = "Encoding",
					variable = Checkbutton1,
					onvalue = 1,
					offvalue = 0,
					height = 2,
					width = 10)

Button2 = Checkbutton(root, text = "Restore",
					variable = Checkbutton2,
					onvalue = 1,
					offvalue = 0,
					height = 2,
					width = 10)
Button3 = Button(root,text = "Submit",command=analyze)

	
Button1.pack()
Button2.pack()
Button3.pack()






mainloop()
